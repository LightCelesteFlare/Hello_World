﻿namespace Assignment1
{
    partial class Drawing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radBtnBlack = new System.Windows.Forms.RadioButton();
            this.radBtnGreen = new System.Windows.Forms.RadioButton();
            this.radBtnBlue = new System.Windows.Forms.RadioButton();
            this.radBtnRed = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radBtnLarge = new System.Windows.Forms.RadioButton();
            this.radBtnMedium = new System.Windows.Forms.RadioButton();
            this.radBtnSmall = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radBtnBlack);
            this.groupBox1.Controls.Add(this.radBtnGreen);
            this.groupBox1.Controls.Add(this.radBtnBlue);
            this.groupBox1.Controls.Add(this.radBtnRed);
            this.groupBox1.Location = new System.Drawing.Point(22, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(95, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Colour";
            // 
            // radBtnBlack
            // 
            this.radBtnBlack.AutoSize = true;
            this.radBtnBlack.Checked = true;
            this.radBtnBlack.Location = new System.Drawing.Point(7, 92);
            this.radBtnBlack.Name = "radBtnBlack";
            this.radBtnBlack.Size = new System.Drawing.Size(52, 17);
            this.radBtnBlack.TabIndex = 3;
            this.radBtnBlack.TabStop = true;
            this.radBtnBlack.Text = "Black";
            this.radBtnBlack.UseVisualStyleBackColor = true;
            this.radBtnBlack.CheckedChanged += new System.EventHandler(this.radBtnBlack_CheckedChanged);
            // 
            // radBtnGreen
            // 
            this.radBtnGreen.AutoSize = true;
            this.radBtnGreen.Location = new System.Drawing.Point(7, 68);
            this.radBtnGreen.Name = "radBtnGreen";
            this.radBtnGreen.Size = new System.Drawing.Size(54, 17);
            this.radBtnGreen.TabIndex = 2;
            this.radBtnGreen.TabStop = true;
            this.radBtnGreen.Text = "Green";
            this.radBtnGreen.UseVisualStyleBackColor = true;
            this.radBtnGreen.CheckedChanged += new System.EventHandler(this.radBtnGreen_CheckedChanged);
            // 
            // radBtnBlue
            // 
            this.radBtnBlue.AutoSize = true;
            this.radBtnBlue.Location = new System.Drawing.Point(7, 44);
            this.radBtnBlue.Name = "radBtnBlue";
            this.radBtnBlue.Size = new System.Drawing.Size(46, 17);
            this.radBtnBlue.TabIndex = 1;
            this.radBtnBlue.TabStop = true;
            this.radBtnBlue.Text = "Blue";
            this.radBtnBlue.UseVisualStyleBackColor = true;
            this.radBtnBlue.CheckedChanged += new System.EventHandler(this.radBtnBlue_CheckedChanged);
            // 
            // radBtnRed
            // 
            this.radBtnRed.AutoSize = true;
            this.radBtnRed.Location = new System.Drawing.Point(7, 20);
            this.radBtnRed.Name = "radBtnRed";
            this.radBtnRed.Size = new System.Drawing.Size(45, 17);
            this.radBtnRed.TabIndex = 0;
            this.radBtnRed.TabStop = true;
            this.radBtnRed.Text = "Red";
            this.radBtnRed.UseVisualStyleBackColor = true;
            this.radBtnRed.CheckedChanged += new System.EventHandler(this.radBtnRed_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radBtnLarge);
            this.groupBox2.Controls.Add(this.radBtnMedium);
            this.groupBox2.Controls.Add(this.radBtnSmall);
            this.groupBox2.Location = new System.Drawing.Point(22, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(92, 94);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Size";
            // 
            // radBtnLarge
            // 
            this.radBtnLarge.AutoSize = true;
            this.radBtnLarge.Location = new System.Drawing.Point(7, 67);
            this.radBtnLarge.Name = "radBtnLarge";
            this.radBtnLarge.Size = new System.Drawing.Size(52, 17);
            this.radBtnLarge.TabIndex = 2;
            this.radBtnLarge.TabStop = true;
            this.radBtnLarge.Text = "Large";
            this.radBtnLarge.UseVisualStyleBackColor = true;
            this.radBtnLarge.CheckedChanged += new System.EventHandler(this.radBtnLarge_CheckedChanged);
            // 
            // radBtnMedium
            // 
            this.radBtnMedium.AutoSize = true;
            this.radBtnMedium.Location = new System.Drawing.Point(7, 44);
            this.radBtnMedium.Name = "radBtnMedium";
            this.radBtnMedium.Size = new System.Drawing.Size(62, 17);
            this.radBtnMedium.TabIndex = 1;
            this.radBtnMedium.TabStop = true;
            this.radBtnMedium.Text = "Medium";
            this.radBtnMedium.UseVisualStyleBackColor = true;
            this.radBtnMedium.CheckedChanged += new System.EventHandler(this.radBtnMedium_CheckedChanged);
            // 
            // radBtnSmall
            // 
            this.radBtnSmall.AutoSize = true;
            this.radBtnSmall.Location = new System.Drawing.Point(7, 20);
            this.radBtnSmall.Name = "radBtnSmall";
            this.radBtnSmall.Size = new System.Drawing.Size(50, 17);
            this.radBtnSmall.TabIndex = 0;
            this.radBtnSmall.TabStop = true;
            this.radBtnSmall.Text = "Small";
            this.radBtnSmall.UseVisualStyleBackColor = true;
            this.radBtnSmall.CheckedChanged += new System.EventHandler(this.radBtnSmall_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(140, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(227, 215);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Drawing_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Drawing_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Drawing_MouseUp);
            // 
            // Drawing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 262);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Drawing";
            this.Text = "Drawing";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radBtnBlack;
        private System.Windows.Forms.RadioButton radBtnGreen;
        private System.Windows.Forms.RadioButton radBtnBlue;
        private System.Windows.Forms.RadioButton radBtnRed;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radBtnLarge;
        private System.Windows.Forms.RadioButton radBtnMedium;
        private System.Windows.Forms.RadioButton radBtnSmall;
        private System.Windows.Forms.Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}