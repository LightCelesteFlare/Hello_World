﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    public partial class TemperatureConvert : Form
    {
        public TemperatureConvert()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double Celsius;
            double Fahren = Convert.ToDouble(txtFahrenheit.Text);

            Celsius = ((0.5556) * (Fahren - 32));
            txtTem.Text = Convert.ToString(Celsius);
        }
    }
}
