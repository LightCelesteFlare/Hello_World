﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    public partial class Drawing : Form
    {
        bool ShouldPaint { get; set; } = false;
        int size = 4;
        Brush colour = new SolidBrush(Color.Red);
        public Drawing()
        {
            InitializeComponent();
        }

        private void Drawing_MouseDown(object sender, MouseEventArgs e)
        {
            ShouldPaint = true;
        }

        private void Drawing_MouseUp(object sender, MouseEventArgs e)
        {
            ShouldPaint = false;
        }

        private void Drawing_MouseMove(object sender, MouseEventArgs e)
        {
            if (ShouldPaint)
            {
                using (Graphics graphics = panel1.CreateGraphics())
                {                
                    graphics.FillEllipse(colour, e.X, e.Y, size, size);                 
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void radBtnRed_CheckedChanged(object sender, EventArgs e)
        {
            colour = new SolidBrush(Color.Red);
        }

        private void radBtnBlue_CheckedChanged(object sender, EventArgs e)
        {
            colour = new SolidBrush(Color.Blue);
        }

        private void radBtnGreen_CheckedChanged(object sender, EventArgs e)
        {
            colour = new SolidBrush(Color.Green);
        }

        private void radBtnBlack_CheckedChanged(object sender, EventArgs e)
        {
            colour = new SolidBrush(Color.Black);
        }

        private void radBtnSmall_CheckedChanged(object sender, EventArgs e)
        {
            size = 4;
        }

        private void radBtnMedium_CheckedChanged(object sender, EventArgs e)
        {
            size = 6;
        }

        private void radBtnLarge_CheckedChanged(object sender, EventArgs e)
        {
            size = 9;
        }
    }
}
